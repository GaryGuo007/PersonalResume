<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<title>ECT 436</title>
</head>
<body>
<div class="container">
	<div class="head">
	<p><h1>ECT436 Social Marketing and Social Networking Applications</h1><h3>Winter 2017</h3></p>
	</div>

	<div class="menu">
		<ul>
			<a href="../index.php"><li>Assignment 1</li></a>
			<a href="../assign2/index.php"><li>Assignment 2</li></a>
			<a href="../assign3/index.php"><li>Assignment 3</li></a>
			<a href="../DeliverableA/index.php"><li>Deliverable A</li></a>
			<a href="../assign4/index.php"><li>Assignment 4</li></a>
			<a href="../DeliverableB/index.php" class="current"><li>Deliverable B</li></a>
		</ul>
	</div>

	<div class="content"><a name="0"></a>
		<div class="proposal">
			<div>
			<h2>PHP Web Application</h2>
			</div>
			<div class="point" name="1">
				<h2><a name="1">Website URL</a></h2>
				<p><a href="http://ectweb.cs.depaul.edu/XGUO9/assign4/index.php">Gambling Now</a></p>
				<p><a href="http://ectweb.cs.depaul.edu/wtiencha/assign4/index.php">House of Aid</a></p>
				<p><a href="https://drive.google.com/open?id=0B1okaS5gznwSNDZRMndfQTlQTDA">Presentation PowerPoint</a></p>
				<p><a href="http://ectweb.cs.depaul.edu/XGUO9/DeliverableB/ppt.pptx">PowerPoint Download</a></p>
			</div>
			<div class="point" >
				<h2><a name="2">The List of Implemented Functions</a></h2>
					<ol>
						<li>User login session</li>
						<li>User registration</li>
						<li>Weather information</li>
						<li>User personal profile</li>
						<li>Login as an admin to check all uses profile informations</li>
						<li>My Live chat</li>
						<li>Security Check, no login, no way to play</li>
					</ol>	
				<h2><a name="4">Technologies</a></h2>
					<ol>
						<li>Bootstrap: carousel slide/navbar</li>
						<li>PHP Filters: email validation</li>
						<li>PHP 5 Forms:Validate Name</li>
						<li>Session: Login/Register</li>
						<li>API: Weather information</li>
						<li>Database: Access</li>
						<li>Javascript/JQuery: Security Check, no login, no way to play</li>
						<li>SHORTCUT ICON: .ico</li>
						<li>My Live chat and phone application</li>
						<li>Facebook like and share button</li>
					</ol>				
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>		
			<div class="point" >
				<h2><a name="3">Website Sitemap And Associated Files</a></h2>
				<img src="sitemap.png" alt="sitemap"/>
				<h3>Database Entity Relationship Diagram</h3>
				<img src="database.png" alt="database"/>
				<p><span class="back"><a href="#0">Go to top</a></p>

			</div>

			<div class="point">
				<h2><a name="5">Activity Diagrams</a></h2>
				<img src="Activity_Diagram.png"  alt="Activity Diagram"/>
				<br />
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>
			<div class="point">
				<h2><a name="6">Interface requirement and wireframes</a></h2>
				<h3>Interface requirements </h3>
				<p>The application will perform under 1366x768 resolutions. JavaScript will be used for validation. A global CSS will be used for formatting.</p>
				<h3>Wireframe - website home page</h3>
				<img src="Homepage.png" alt="Homepage"/>
				<br />
				<img src="Registration.png" alt="module1"/>
				<br />
				<img src="Login.png" alt="module2"/>
				<br />
				<img src="Account.png" alt="module3"/>
				<br />
				<img src="Game.png" alt="module4"/>
				<br />
				<img src="Results.png" alt="module5"/>
				<p>The Main Content shows different contents depend on each page feature so it also provides different optional button(s) for navigation.  The dynamic content is based on each user's personal information displaying his or her owned travel schedule.  The layout plan is as following:</p>
				<table>
					<tr>
						<td class="field">Display Page</td>
						<td class="field">Main Content View</td>
					</tr>
					<tr>
						<td class="wcol1">Home Page</td>
						<td class="wcol2">Single view of the instruction illustration and description</td>
					</tr>
					<tr>
						<td class="wcol1">Result page</td>
						<td class="wcol2">List the result of gambling</td>
					</tr>
					<tr>
						<td class="wcol1">Profile page</td>
						<td class="wcol2">Detail view of information at a place</td>
					</tr>
					<tr>
						<td class="wcol1">Registration page</td>
						<td class="wcol2">Form view to enter and submit registration</td>
					</tr>
				</table>
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>

		<div class="footer">
			<p>This is an educational website.  Copyright 2017</p>
		</div>
		
	</div>

</div>
</body>
</html>