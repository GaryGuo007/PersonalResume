<html>
<head>
<link rel="stylesheet" type="text/css" href="../../stylepage.css">
<title> Hi there </title>
</head>
<script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>
<body>
<h1> Check this out --</h1>
<h3> You account has been created! </h3>
<?php
$nameData = filter_input(INPUT_GET, "userName");
$emailData = filter_input(INPUT_GET, "email");
$passwordData = filter_input(INPUT_GET, "password");
print "<h3>Hi there, " . $nameData . "!</h3> <p/>
 <h3>Your email is: " . $emailData . "!</h3>
 <h3>Your password is: " . $passwordData . "!</h3>";
?>
<div class="row">
			<h3>Assignment Description</h3>
			<ul>
				<li><a href="/XGUO9/index.php">Assignment#1</a> Please create a simple HTML page that contains your personal information and links to your future assignments.</li>
				<li><a href="/XGUO9/assign2/index.php">Assignment#2</a> Develop a simple PHP Web site that allows a user to enter some information in a HTML form and responds to the user's input.</li>
				<li><a href="../assign3/index.php">Assignment#3</a> Develop a PHP page that uses at least two of the following control structures: if-else, switch, for loop, and while loop.</li>
				<li><a href="../deliverableA/index.php">Deliverable A</a> Design of the final project.</li>
				<li><a href="../assign4/index.php">Assignment#4</a> Develop PHP pages that take input from user and return records from database that match user input.</li>
				<li><a href="../deliverableB/index.php">Deliverable B</a> Final project Web site and documentation..</li>
			</ul>
		</div>
		<div class="footer">
			<p>This is an educational website.  Copyright 2017 All Rights reserved Xin Guo</p>
		</div>
</body>
</html>