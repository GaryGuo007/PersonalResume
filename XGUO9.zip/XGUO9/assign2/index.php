<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
   <link rel="SHORTCUT ICON" href="Mario.ico" />

    <title>ECT 436 Assignments 1</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>

</head>

<body>
<h1> What's your Name?</h1>
<h3> Setting up a form to solicit user input</h3>
<p>
<form method = "get" action="RegisterResponse.php">
Please type your name:
<input type="text" name="userName"> <p/>
Please type your email:
<input type="text" name="email"><p/>
Please type your password:
<input type="text" name="password"><p/>
<input type="submit" class="button" value="Register">
</form>
</p>
<div class="row">
			<h3>Assignment Description</h3>
			<ul style="list-style-position:outside circle">
				<li><a href="../assign1/index.php">Assignment#1</a> Please create a simple HTML page that contains your personal information and links to your future assignments.</li>
				<li><a href="../assign2/index.php">Assignment#2</a> Develop a simple PHP Web site that allows a user to enter some information in a HTML form and responds to the user's input.</li>
				<li><a href="../assign3/index.php">Assignment#3</a> Develop a PHP page that uses at least two of the following control structures: if-else, switch, for loop, and while loop.</li>
				<li><a href="../deliverableA/index.php">Deliverable A</a> Design of the final project.</li>
				<li><a href="../assign4/index.php">Assignment#4</a> Develop PHP pages that take input from user and return records from database that match user input.</li>
				<li><a href="../deliverableB/index.php">Deliverable B</a> Final project Web site and documentation..</li>
			</ul>
		</div>
		

<html>
<body>
<form name="blah_blah">
<select name="ddmenu_name" id="ddmenu_name" style="width: 80% !important;">
<option value="" selected>Select Site</option>
<option value="http://www.yahoo.com">Yahoo!!!</option>
<option value="http://www.gmail.com">Gmail</option>
<option value="http://www.google.co.in">Google</option>
<option value="http://www.facebook.com">Facebook</option>
</select>
<input type="button" name="Submit" value="Go!" onClick="window.open(ddmenu_name.value,'newtab'+ddmenu_name.value)">
</form>
</body>
</html>



<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
  </ol>
	  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="1.jpg" alt="Chania">
      <div class="carousel-caption">
        <h3>Lamborghini</h3>
        <p>Automobili Lamborghini is an Italian brand and manufacturer of luxury sports cars and SUVs based in Sant'Agata Bolognese, Italy. </p>
      </div>
    </div>

    <div class="item">
      <img src="2.jpg" alt="Chania">
      <div class="carousel-caption">
        <h3>House</h3>
        <p>The house is a waterfront mansion in a gated golf community worth well over seven figures.</p>
      </div>
    </div>

    <div class="item">
      <img src="3.jpg" alt="Flower">
      <div class="carousel-caption">
        <h3>A million dollars</h3>
        <p>Win a million dollars, Who Wants to Be the Millionaire?</p>
      </div>
    </div>

    <div class="item">
      <img src="4.jpg" alt="Flower">
      <div class="carousel-caption">
        <h3>AUG Automatic Rifle</h3>
        <p>The Steyr AUG is an Austrian bullpup 5.56�45mm NATO assault rifle.</p>
      </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

    <!--<script id="feedTemplate" type="text/x-kendo-template">
        <div>
            <span>#=title</span>
            <span>#=date</span>
            <span>#=Description#</span>
            <span>#=link</span>
        </div>
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            //feed to parse
            var feed = "http://www.eventionllc.com/feed/?format=xml";

            // Once: compile the feed item template
            // var template = kendo.template($("#feedTemplate").html());

            // // Generate the item content from the template. This will be a snippet of HTML
            // var content = template(model);
     
            // // Append the item content to the carousel
            // $(content).appendTo(carouselContainer);


            $.ajax(feed, {
                accepts: {
                    xml: "application/rss+xml"
                },
                dataType: "xml",
                success: function (data) {

                    // 1. Remove all existing feed items

                    // 2. For each item in "data"

                    //      parse into model
                    //      generate item HTML using template above
                    //      append HTML to carousel





                    //Credit: http://stackoverflow.com/questions/10943544/how-to-parse-an-rss-feed-using-javascript
                    $(data).find("item").each(function () { // or "item" or whatever suits your feed
                        var el = $(this);
                        //console.log("------------------------");
                        console.log("title      : " + el.find("title").text());
                        console.log("date      : " + el.find("pubDate").text());
                        console.log("description: " + el.find("description").text());
                        console.log("link       : " + el.find("link").text());
                    });

                }
            });

        });

    </script>-->



<div class="footer">
			<p>This is an educational website.  Copyright 2017 All Rights reserved Xin Guo</p>
		</div>
</body>
</html>