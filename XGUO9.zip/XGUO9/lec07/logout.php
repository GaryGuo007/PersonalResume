<?php
session_start();
?>
<html>
<head>
  <title>Logout</title>
  <link rel="stylesheet" type="text/css" href="../../stylepage.css">
</head>
</body>
<?php
   session_destroy();
   print "You are now logged out <a href=index.php>Index</a> or <a href=login.php>Login</a>";
 ?>
 </body>
 </html>