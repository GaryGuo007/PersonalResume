<?php
session_start();
?>
<html>
<head>
<title> Welcome page </title>
<link rel="stylesheet" type="text/css" href="../../stylepage.css">
</head>
<body>
<?php
session_save_path("E:\\ectweb.cs.depaul.edu\\XGUO9\\Database");
if (isset($_SESSION["username"]))
{
    $username = $_SESSION["username"];
	print "Welcome " . $username . " (<a href=logout.php>Logout</a>)";
}
else
{
    print "Welcome Guest!<br> <a href=login.php>Login</a> |
           <a href=register.php>Register</a>";
}
?>
</body>
</html>