<?php
session_start();
?>
<html>
<head>
  <title>Login</title>
  <link rel="stylesheet" type="text/css" href="../../stylepage.css">
</head>
</body>
<?php
function DisplayLoginScreen()
{
   print  "<form action='?act=CheckPassword' method='post'>\n"
         . "email address: <input type='text' name='email' size='50'><p />\n"
         . "password: <input type='password' name='password' size='30'><p />\n"
         . "<input type='submit' value='Login'>\n"
         . "</form>\n";
 }

 function CheckPassword()
 {
	$username = filter_input(INPUT_POST, "email");
	$password = filter_input(INPUT_POST, "password");

    // connect with the database
	$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../Database/lecture07.mdb;Persist Security Info=False;";
	try {
		$conn = new COM('ADODB.Connection');
		$conn->ConnectionTimeout = 60;
		$conn->Open($connString);
	} catch (exception $e) {
		die( "Could not connect - $e");
	}
	// check that the email address (username) is not already in the database
	$sqlCommand = "SELECT * FROM customers WHERE email = '$username' AND securityWord='$password';";
	print $sqlCommand . "<p/>";
	$rs = $conn->Execute($sqlCommand);
	if($rs->EOF) {
	     die("incorrect username or password.");
	}
	$rs->Close();
	//  Yay!  login is good -- let's keep track of this visitor

	$_SESSION["username"] = $username;

    print "Welcome, $username! Please continue on to our <a href=index.php>Index</a>";
 }

 if (filter_has_var(INPUT_GET,"act"))
     CheckPassword();
 else
     DisplayLoginScreen();
 ?>
 </body>
 </html>