<?php
session_start();
?>

<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>Switch Dice</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Gambling Now</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/XGUO9/index.php">Home</a></li>
      <li><a href="/XGUO9/assign3/index.php">Weather Forecast</a></li>
      <li><a href="/XGUO9/assign4/index.php">Gambling</a></li>
      <li><a href="/XGUO9/assign4/Login/profile.php">Profile</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="/XGUO9/assign4/Login/register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="/XGUO9/assign4/Login/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>

<?php
session_save_path("E:\\ectweb.cs.depaul.edu\\XGUO9\\Database");
if (isset($_SESSION["username"]))
{
    $username = $_SESSION["username"];
	print "Welcome " . $username . " (<a href=Login/logout.php>Logout</a>)";
}
else
{
    print "Welcome Guest! Please register or Login first and then you can Bet.<br>";
}


$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../Database/lecture07.mdb;Persist Security Info=False;";
try {
    $conn = new COM('ADODB.Connection');
    $conn->ConnectionTimeout = 60;
    $conn->Open($connString);
} catch (exception $e) {
    die( "Could not connect - $e");
}
print "<ul>";
// check that the email address (username) is not already in the database
if (isset($_SESSION["username"])){
    $rs = $conn->Execute("SELECT * FROM customers WHERE email = '" . $username . "';");
    
    if (!$rs->EOF) {
        $fv=$rs->Fields("startCash");
        if($fv<0){header('Location: http://ectweb.cs.depaul.edu/XGUO9/assign4/Login/addMoney.php'); exit;}
        print "Cash You Have Now :  $fv</a></li><br/>";
        $rs->MoveNext();
    }
    $rs->Close();
    print "</ul>";
}

?>

<h1>SwitchDice</h1>
<!--<h3>Demonstrates switch structure</h3>-->
<?php
$roll = rand(1,6);
switch ($roll){
case 1:
$romValue = "I";
break;
case 2:
$romValue = "II";
break;
case 3:
$romValue = "III";
break;
case 4:
$romValue = "IV";
break;
case 5:
$romValue = "V";
break;
case 6:
$romValue = "VI";
break;
default:
print "This is an illegal die!";
} // end switch
print <<< HERE
<p>You rolled a $roll.</p>
<p>
<img src = "images/dice-$roll.png"
alt = "die: $roll" />
</p>
<p>In Roman numerals, that's $romValue.</p>
HERE;

$chip = filter_input(INPUT_POST, "chip");
$total = 0;
 $sum = 0;
 $newTotal=0;
if (filter_has_var(INPUT_POST,"big") && $roll > 3 )
{
print"<p>You choose big, right decision, you Win $chip US dollar! </p>\n";
print <<< HERE

<p>
<img src = "images/win.jpg" />
</p>

HERE;
$total = $total + $chip;
}
if (filter_has_var(INPUT_POST,"small") && $roll < 4)
{
print"<p>You choose small, right decision, you Win $chip US dollar! </p>\n";
print <<< HERE

<p>
<img src = "images/win.jpg" />
</p>

HERE;
$total = $total + $chip;
}

if (filter_has_var(INPUT_POST,"big") && $roll < 4 )
{
print"<p>You choose big, wrong decision, you lose $chip US dollar. </p>\n";
print <<< HERE

<p>
<img src = "images/lose.jpg" />
</p>

HERE;
$total = $total - $chip;
}
if (filter_has_var(INPUT_POST,"small") && $roll > 3)
{
print"<p>You choose small, wrong decision, you lose $chip US dollar.  </p>\n";
print <<< HERE

<p>
<img src = "images/lose.jpg" />
</p>

HERE;
$total = $total - $chip;
}


if($total<0)
{
    $sum = $total*(-1);
print"<p>You have lose $sum US dollar. Keep your chin up!</p>\n";
}
if($total>0)
{
print"<p>You have won $total US dollar! Carry on!!!  </p>\n";
}
if($total==0)
{
print"<p>He neither won nor lost money.  </p>\n";
}
 
$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../Database/lecture07.mdb;Persist Security Info=False;";
try {
    $conn = new COM('ADODB.Connection');
    $conn->ConnectionTimeout = 60;
    $conn->Open($connString);
} catch (exception $e) {
    die( "Could not connect - $e");
}
print "<ul>";


if (isset($_SESSION["username"])){
$fvv=$conn->Execute("SELECT * FROM customers WHERE email = '" . $username . "';");
if (!$fvv->EOF)
{  
     $startcash = $fvv->Fields("startCash");
     if (!empty($startcash))  
     {
            $newTotal = $startcash  + $total;
     }
}
}
$rs2 = $conn->Execute("UPDATE customers SET startCash = '".$newTotal."' WHERE email = '" . $username . "';");
if (isset($_SESSION["username"])){
    $rs3 = $conn->Execute("SELECT * FROM customers WHERE email = '" . $username . "';");
    if (!$rs3->EOF)
        {
        $fv2=$rs3->Fields("startCash");
        if($fv2<0){header('Location: http://ectweb.cs.depaul.edu/XGUO9/assign4/Login/addMoney.php'); exit;}
        print "Cash You Have Now :  $fv2</a></li><br/>";
        $rs3->MoveNext();
        }
    $rs3->Close();
    print "</ul>";
    }

?>
<p>Refresh this page in the browser to roll another die.</p>
</body>
</html>