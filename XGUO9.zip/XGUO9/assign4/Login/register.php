<?php
session_start();
?>
  <html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>

    <link rel="SHORTCUT ICON" href="GreenDollar.ico" />
    <title>Register</title>
    <!--<link rel="stylesheet" type="text/css" href="style.css">-->
  </head>
  <link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Gambling Now</a>
      </div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="/XGUO9/index.php">Home</a></li>
        <li><a href="/XGUO9/assign3/index.php">Weather Forecast</a></li>
        <li><a href="/XGUO9/assign4/index.php">Gambling</a></li>
        <li><a href="/XGUO9/assign4/Login/profile.php">Profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="/XGUO9/assign4/Login/register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="/XGUO9/assign4/Login/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </nav>


  </body>
  <?php
function showRegistrationForm()
{
    
    print  "<form action='?act=register' method='post' style=position:center>\n"
    . "&nbsp&nbsp&nbsp&nbsp&nbspEmail address: <label><input type='text' name='email' size='50'></label><br />\n"
    . "&nbsp&nbsp&nbsp&nbsp&nbspName: <label><input type='text' name='name' size='50'></label><br />\n"
    . "&nbsp&nbsp&nbsp&nbsp&nbspPassword: <label><input type='password' name='password' size='30'></label><br />\n"
    . "&nbsp&nbsp&nbsp&nbsp&nbspConfirm your password: <label><input type='password' name='confirmPassword' size='30'></label><br />\n"
    . "&nbsp&nbsp&nbsp&nbsp&nbspDebit Account Number: <label><input type='number' name='account' size='50'></label><br />\n"
    . "&nbsp&nbsp&nbsp&nbsp&nbspStart Cash: <label><input type='number' name='startCash' size='50'></label><br />\n"
    . "&nbsp&nbsp&nbsp&nbsp&nbsp<input type='submit' value='Register'>\n"
    . "</form>\n";
}

function processRegistration()
{
    // check user input, to see if it's OK
    // in practice, it's better to do this in Javascript
    // but it's possible do perform this task on the
    // server side as well.
    $name = filter_input(INPUT_POST, "name");
    if(empty($name)) {
        die("Please enter your name");
    }
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       die("Only letters and white space allowed"); 
    }
    $username = filter_input(INPUT_POST, "email");
    if(empty($username)) {
        die("Please enter your email address");
    }
    if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format"); 
    }
    $password = filter_input(INPUT_POST, "password");
    if(empty($password)){
        die ("Please supply a password.");
    }
    $password_duplicate = filter_input(INPUT_POST, "confirmPassword");
    if(empty($password_duplicate)){
        die ("Please confirm your password.");
    }
    if($password != $password_duplicate) {
        die ("Passwords don't match.");
    }
    $account = filter_input(INPUT_POST, "account");
    if(empty($account)){
        die("Please enter your account number");
    }

    $startCash = filter_input(INPUT_POST, "startCash");
    if(empty($startCash)){
        die("Please enter your start cash");
    }

    if($startCash<1){
        die("Please enter right start cash");
    }
    
    // connect with the database
    $connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../../Database/lecture07.mdb;Persist Security Info=False;";
    try {
        $conn = new COM('ADODB.Connection');
        $conn->ConnectionTimeout = 60;
        $conn->Open($connString);
    } catch (exception $e) {
        die( "Could not connect - $e");
    }
    // check that the email address (username) is not already in the database
    $sqlCommand = "SELECT * FROM customers WHERE email = '" . $username . "';";
   // print $sqlCommand . "<p/>";
    $rs = $conn->Execute($sqlCommand);
    if(!$rs->EOF) {
        $rs->Close();
        die ("That email has already been taken.  Please use another.");
    }
    $rs->Close();
    //Yay!  We have good data.  Insert it into the database
    $date = date('d-m-Y H:i:s');
    $sqlCommand = "INSERT INTO customers (name, email, securityWord, account, startCash, dateJoined) VALUES ("
    . "'$name','$username','$password', '$account', '$startCash',  #$date#);";
    
   // print $sqlCommand;
    try {
        $conn->Execute($sqlCommand);
    }
    catch (exception $e) {
        die ("sql error:  $e");
    }
    $conn->Close();
    print "<p/> $username, You are now registered.  Thank you!<p/>
    <a href=login.php>Login</a> | <a href=../index.php>Index</a>";
    
}

if (filter_has_var(INPUT_GET,"act"))
    processRegistration();
else
    showRegistrationForm();
?>
    </body>

  </html>