<?php
session_start();
?>
  <html>

  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>

    <link rel="SHORTCUT ICON" href="GreenDollar.ico" />
    <title> Customer Profile Page </title>
    <!--<link rel="stylesheet" type="text/css" href="../../stylepage.css">-->
  </head>

  <body>

    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="#">Gambling Now</a>
        </div>
        <ul class="nav navbar-nav">
          <li class="active"><a href="/XGUO9/index.php">Home</a></li>
          <li><a href="/XGUO9/assign3/index.php">Weather Forecast</a></li>
          <li><a href="/XGUO9/assign4/index.php">Gambling</a></li>
          <li><a href="/XGUO9/assign4/Login/profile.php">Profile</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><a href="/XGUO9/assign4/Login/register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
          <li><a href="/XGUO9/assign4/Login/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
        </ul>
      </div>
    </nav>



    <?php
session_save_path("E:\\ectweb.cs.depaul.edu\\XGUO9\\Database");
if (isset($_SESSION["username"]))
{
    $username = $_SESSION["username"];
}
else
{
    print "Welcome Guest! You have not log in, please register or login first. <br> <a href=login.php>Login</a> |
    <a href=register.php>Register</a>";
}


// connect with the database
$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../../Database/lecture07.mdb;Persist Security Info=False;";
try {
    $conn = new COM('ADODB.Connection');
    $conn->ConnectionTimeout = 60;
    $conn->Open($connString);
} catch (exception $e) {
    die( "Could not connect - $e");
}
print "<ul>";
// check that the email address (username) is not already in the database
if (isset($_SESSION["username"])){

if($username=="admin@126.com"){
  $as = $conn->Execute("SELECT * FROM customers;");
    
    while (!$as->EOF) {
        $fva1=$as->Fields("account");
        $fva2=$as->Fields("dateJoined");
        $fva3=$as->Fields("securityWord");
        $fva4=$as->Fields("email");
        $fva5=$as->Fields("ID");
		$fva6=$as->Fields("startCash");
        $fva7=$as->Fields("name");

		
		print "ID :  $fva5</a></li><br/>";
        print "Name :  $fva7</a></li><br/>";
        print "Email Address :  $fva4</a></li><br/>";
        print "Password :  $fva3</a></li><br/>";
        print "Account Number : $fva1</a></li><br/>";
		print "Cash You Have Now : $fva6</a></li><br/>";
        print "Date joined :  $fva2</a></li><br/>";
		print "<p></p>";
        $as->MoveNext();
    }
	 $as->Close();
    print "</ul>";
}
else{
    $rs = $conn->Execute("SELECT * FROM customers WHERE email = '" . $username . "';");
    
    if(!$rs->EOF) {
        $fv1=$rs->Fields("account");
        $fv2=$rs->Fields("dateJoined");
        $fv3=$rs->Fields("securityWord");
        $fv4=$rs->Fields("email");
		$fv5=$rs->Fields("startCash");
        $fv7=$rs->Fields("name");
        
        print "Name :  $fv7</a></li><br/>";
        print "Email Address :  $fv4</a></li><br/>";
        print "Password :  $fv3</a></li><br/>";
        print "Account Number : $fv1</a></li><br/>";
		print "Cash You Have Now : $fv5</a></li><br/>";
        print "Date joined :  $fv2</a></li><br/>";
        $rs->MoveNext();
    }
	 $rs->Close();
    print "</ul>";
}
   

	
}

?>
  </body>

  </html>