<?php
session_start();
?>
  <html>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="stylepage.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>

    <link rel="SHORTCUT ICON" href="GreenDollar.ico" />
    <title>Logout</title>
    <!--<link rel="stylesheet" type="text/css" href="../../stylepage.css">-->
  </head>

  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">Gambling Now</a>
      </div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="/XGUO9/index.php">Home</a></li>
        <li><a href="/XGUO9/assign3/index.php">Weather Forecast</a></li>
        <li><a href="/XGUO9/assign4/index.php">Gambling</a></li>
        <li><a href="/XGUO9/assign4/Login/profile.php">Profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="/XGUO9/assign4/Login/register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="/XGUO9/assign4/Login/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
      </ul>
    </div>
  </nav>


  </body>
  <?php
session_unset();
session_destroy();
print "You are now logged out because you do not have enough money. <a href=../index.php>Index</a> or <a href=login.php>Login</a> or <a href=register.php>Sign Up</a>";
?>
    </body>

  </html>