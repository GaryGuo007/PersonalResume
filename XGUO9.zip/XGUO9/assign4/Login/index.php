<?php
session_start();
setcookie("username", $_SESSION["username"], time()+3600);
?>
  <html>

  <head>
    <link rel="SHORTCUT ICON" href="GreenDollar.ico" />
    <title> Welcome page </title>
    <!--<link rel="stylesheet" type="text/css" href="../../stylepage.css">-->
  </head>

  <body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=999198200189282";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<div class="fb-like" data-href="http://ectweb.cs.depaul.edu/XGUO9/assign4/index.php" data-layout="standard" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>

    <?php
session_save_path("E:\\ectweb.cs.depaul.edu\\XGUO9\\Database");
session_set_cookie_params(24*3600);
if (isset($_SESSION["username"]))
{
    $username = $_SESSION["username"];
    print "Welcome " . $username . " (<a href=Login/logout.php>Logout</a>)";
}
else
{
    print "Welcome Guest!<br> <a href=login.php>Login</a> |
    <a href=register.php>Register</a>";
}

if(isset($_COOKIE["username"]))
{
    $username = $_COOKIE["username"];
    echo "Welcome " . $username . "! (<a href=Login/logout.php>Logout</a>)";
}
// else
// {
//     echo "Welcome Guest!<br> <a href=login.php>Login</a> |
//            <a href=register.php>Register</a>";
// }
?>
  </body>

  </html>