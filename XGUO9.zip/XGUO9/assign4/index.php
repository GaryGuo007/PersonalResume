<?php
session_start();
?>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="stylepage.css">

<link rel="SHORTCUT ICON" href="GreenDollar.ico" />
<title>Gambling Now</title>

<script>
$('input[type="checkbox"]').on('change', function() {
   $(this).siblings('input[type="checkbox"]').prop('checked', false);
});
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>
<script>
$(function() { 
  $('input[type="checkbox"]').bind('click',function() {
    $('input[type="checkbox"]').not(this).prop("checked", false);
  });
});
</script>

</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Gambling Now</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/XGUO9/index.php">Home</a></li>
      <li><a href="/XGUO9/assign3/index.php">Weather Forecast</a></li>
      <li><a href="/XGUO9/assign4/index.php">Gambling</a></li>
      <li><a href="/XGUO9/assign4/Login/profile.php">Profile</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="/XGUO9/assign4/Login/register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="/XGUO9/assign4/Login/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
<?php
session_save_path("E:\\ectweb.cs.depaul.edu\\XGUO9\\Database");
if (isset($_SESSION["username"]))
{
    $username = $_SESSION["username"];
	print "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Welcome " . $username . " (<a href=Login/logout.php>Logout</a>)";
}
else
{
    print "Welcome Guest! Please register or Login first and then you can Bet.<br>";
}


$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../Database/lecture07.mdb;Persist Security Info=False;";
try {
    $conn = new COM('ADODB.Connection');
    $conn->ConnectionTimeout = 60;
    $conn->Open($connString);
} catch (exception $e) {
    die( "Could not connect - $e");
}
print "<ul>";


if (isset($_SESSION["username"])){
$x=$conn->Execute("SELECT * FROM customers WHERE email = '" . $username . "';");
if (!$x->EOF)
{  
     $cash = $x->Fields("startCash");
     if (!empty($cash))  
     {
       print "Cash You Have Now : $cash</a></li><br/>";    
     }
     $x->MoveNext();
}
$x->Close();
    print "</ul>";
}




?>
 <!--<a href=Login/login.php>Login</a> | <a href=Login/register.php>Register</a>";-->
<h1>Gambling</h1>
<h3>Choose Big or Small</h3>

<form action="result.php" method="post">
<h4>What would you like to choose?</h4>

<input type="checkbox" id="Check1" name="big" checked="checked" value="1.00">Big (4/5/6)<br/>
<input type="checkbox" id="Check2" name="small" value="0.85">Small (1/2/3)<br/>
<br/>
Please type your bargaining chip (USD):
<input type="number" name="chip" min="1" max="100000" required placeholder="Eg. 0.5, 5, 50,...">

&nbsp;<p/>
<!--<input type="submit" value="Bet">-->
<input type='submit' 
<?php  if (!isset($_SESSION["username"])) {?> disabled="disabled" <?php } ?> type="submit"  value='Bet' >

</form>


<!--facebook like and share button-->
<div class="fb-like" data-href="http://ectweb.cs.depaul.edu/XGUO9/assign4/index.php" data-layout="standard" data-action="like" data-size="small" data-show-faces="true" data-share="true"></div>


<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=999198200189282";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="1.jpg" alt="Chania">
      <div class="carousel-caption">
        <h3>Lamborghini</h3>
        <p>Automobili Lamborghini is an Italian brand and manufacturer of luxury sports cars and SUVs based in Sant'Agata Bolognese, Italy. </p>
      </div>
    </div>

    <div class="item">
      <img src="2.jpg" alt="Chania">
      <div class="carousel-caption">
        <h3>House</h3>
        <p>The house is a waterfront mansion in a gated golf community worth well over seven figures.</p>
      </div>
    </div>

    <div class="item">
      <img src="3.jpg" alt="Flower">
      <div class="carousel-caption">
        <h3>A million dollars</h3>
        <p>Win a million dollars, Who Wants to Be the Millionaire?</p>
      </div>
    </div>

    <div class="item">
      <img src="4.jpg" alt="Flower">
      <div class="carousel-caption">
        <h3>AUG Automatic Rifle</h3>
        <p>The Steyr AUG is an Austrian bullpup 5.56�45mm NATO assault rifle.</p>
      </div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


</body>
</html>