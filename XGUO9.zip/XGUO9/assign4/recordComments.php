<html>
<head>
<link rel="stylesheet" type="text/css"
href="../../stylepage.css">
<title> Thank you!</title>
</head>
<body>
<h1> Thank you!</h1>
<p>&nbsp;</p>
We appreciate your taking time to help us improve!
<?php
 if (filter_has_var(INPUT_POST, "inputString"))
 {
 $inputString = filter_input(INPUT_POST,
 "inputString");
 $fp = fopen("Database/customerComments.txt",
 "a+");
 fputs($fp, date(DATE_RFC822) . PHP_EOL);
 fputs($fp, $inputString);
 fputs($fp, PHP_EOL . "-------------" . PHP_EOL);
 fclose($fp);
 }
 ?>
 <p/>
</body>
</html>