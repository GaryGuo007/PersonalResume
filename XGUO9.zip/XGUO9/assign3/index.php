<html>
<head>
	<title>Weather Forecast</title>
    <link rel="stylesheet" type="text/css" href="stylepage.css">
	<meta charset="utf-8" />
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap-theme.min.css">
<link rel="SHORTCUT ICON" href="weather.ico" />
	<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>

</head>

<body>
<li><a href="/XGUO9/index.php" target="_blank" class="btn btn-default custom_btn">Home Page</a></li>

<div class="container">
	
		<div class="row">
			
			<div class="col-md-6 col-md-offset-3 center">
				<form>
					
					<div class="form-group">
						
						<input type="text" class="form-control" name="city" id="city" 
						placeholder="Eg. London, Paris, New York..." />
						
					</div>
					
					<button id="findMyWeather" class="btn btn-success btn-lg">Search</button>
					
				</form>
			
			</div>	
			
		</div>
		
		<div id="success" class="alert alert-success">Success</div>
		
		<div id="fail" class="alert alert-danger">Could not find weather data for that city please try again!</div>
		
		<div id="noCity" class="alert alert-danger">Please enter a City!</div>
		
	</div>
<div class="footer">
<div class="feedback">
	<p> Your feedback is important</p> 
<form action = "feedback.php"
 method = "post">
 <textarea name = "inputString"
 rows = "5"
 cols = "70" >
 </textarea>
 <p/>
 <input type="submit" value = "Send"/>
</form> 
</div>

<div class="uploadFile">
<p> Upload a file</p>
<form action = "fileUpload.php"
 method = "post"
 ENCTYPE="multipart/form-data">
 <p>
 File to upload:
 <input type="file" name="fileToUpload"
 size="30" />
 <p>
 <input type="submit" value="Upload file"
 name="submit" />
</form> 
</div>
	</div>
<script>
	$("#findMyWeather").click(function(event) {
		
		event.preventDefault();
		
		if ($("#city").val()!="") {
			
		
			$.get("scraper.php?city="+$("#city").val(), function( data ) {
				
				if (data=="") {
					
					$(".alert").hide();
					$("#fail").fadeIn();
					
				} else {
					
					$(".alert").hide();
					$("#success").html(data).fadeIn();
					
				}
			
			});
		
		} else {
			
			$(".alert").hide();
			$("#noCity").fadeIn();
			
		}
		
	});
</script>
	
</body>
</html>