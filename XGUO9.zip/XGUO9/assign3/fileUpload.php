<?php
//
// This time, we include some php code before we
// start with the html. That way, if the upload
// fails we will see an error message instead of
// the success page.
//
if($_FILES)
{
 $fname = $_FILES["fileToUpload"]["name"];
 if ($fname != "")
 {
 $destination = "../Database/" .
 $_FILES["fileToUpload"]["name"];
 copy ($_FILES["fileToUpload"]["tmp_name"],
 $destination);
 }
 else
 die("no file specified for upload");
}
else
{
 die("no file specified for upload");
}
 ?>
<html>
<head>
<link rel="stylesheet" type="text/css"
 href="../../stylepage.css">
<title>Success</title>
</head>
<body>
<p>&nbsp;</p>
<h1>Success!</h1>
<p>&nbsp;</p>
 <?php
 $nbytes = $_FILES["fileToUpload"]["size"];
 $fileType = $_FILES["fileToUpload"]["type"];
 print "<p> You sent: $fname having size
$nbytes"
 . " bytes and of type " . $fileType .
"</p>";
 ?>
 <p/>
</body>
</html>