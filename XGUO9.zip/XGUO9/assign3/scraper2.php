<?php

$city=$_GET['city'];
$city=str_replace(" ", "", $city);
$value=null;

try {
	@$contents=file_get_contents("'http://api.openweathermap.org/data/2.5/weather?q=' + .$city. + '&APPID=97e4f1978687357c4c471997509d1ac3&units=metric'");
} catch (Exception $ex) {
	
	alert("wooooooooo");
	$contents="";
	
}

switch($city){
    case 'Chicago': $value = 'Windy City'; break;
    case 'chicago': $value = 'Windy City'; break;
    case 'Taiyuan': $value = 'Dragon City'; break;
    case 'taiyuan': $value = 'Dragon City'; break;
}


if ($contents!=""){
$a=preg_match("/\<span class\=\"phrase\"\>(.*?)\<\/span\>/", $contents, $matches);
print_r($matches[1]);
print($value);
}
?>