<?php

$city=$_GET['city'];
$city=str_replace(" ", "", $city);
$value=null;

try {
	@$contents=file_get_contents("http://www.weather-forecast.com/locations/".$city."/forecasts/latest");
} catch (Exception $ex) {
	
	alert("wooooooooo");
	$contents="";
	
}

switch($city){
    case 'Chicago': $value = 'Windy City'; break;
    case 'chicago': $value = 'Windy City'; break;
    case 'Taiyuan': $value = 'Dragon City'; break;
    case 'taiyuan': $value = 'Dragon City'; break;
}


if ($contents!=""){
$a=preg_match("/\<span class\=\"phrase\"\>(.*?)\<\/span\>/", $contents, $matches);
print_r($matches[1]);
print($value);
}
?>