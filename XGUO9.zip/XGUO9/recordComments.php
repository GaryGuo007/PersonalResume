<html>
<head>
<link rel="stylesheet" type="text/css"
href="../../stylepage.css">
<title> Thank you!</title>
</head>
<body>
<h1> Thank you!</h1>
<p>&nbsp;</p>
We appreciate your taking time to help us improve!
<?php
$nameData = filter_input(INPUT_GET, "name");
$emailData = filter_input(INPUT_GET, "email");
$message = filter_input(INPUT_GET, "message");
print "<h3>Hi there, " . $nameData . "</h3> <p/>
 <h3>Your email is: " . $emailData . "</h3>
 <h3>Your message is: " . $message . "</h3>";


 if ((filter_has_var(INPUT_GET, "name")) || (filter_has_var(INPUT_GET, "email")) ||(filter_has_var(INPUT_GET, "message")))
 {
 $name = filter_input(INPUT_GET,"name");
 $email = filter_input(INPUT_GET,"email");
 $message = filter_input(INPUT_GET,"message");
 $fp = fopen("Database/1.txt","a+");
 fputs($fp, date(DATE_RFC822) . PHP_EOL);
   fputs($fp, $name . PHP_EOL);
   fputs($fp, $email . PHP_EOL);
   fputs($fp, $message);
 fputs($fp, PHP_EOL . "-------------" . PHP_EOL);
 fclose($fp);
 }
 
?>

</body>
</html>