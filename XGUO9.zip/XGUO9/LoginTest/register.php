<!DOCTYPE html>
<?php
session_start();
?>
<html >

<head>
  
<meta charset="UTF-8">
  
<title>Sign-Up/Login Form</title>
  
<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      
<link rel="stylesheet" href="css/style.css">

  

</head>


<body>
  
<div class="form">
      
      
<ul class="tab-group">
        
<!--<li class="tab active"><a href="#signup">Sign Up</a></li>
        
<li class="tab"><a href="#login">Log In</a></li>-->
      
</ul>
      
      
<div class="tab-content">
        
<div id="signup">   
          
<h1>Sign Up for Free</h1>
          
          
<form action="/" method="post">
          
         
 <!--<div class="top-row">
           
 <div class="field-wrap">
              
<label>
                
First Name
<span class="req">*</span>
              
</label>
              
<input type="text" required autocomplete="off" />
           
 </div>
        
            
<div class="field-wrap">
              
<label>
                
Last Name<span class="req">*</span>
              </label>
              
<input type="text"required autocomplete="off"/>
           
 </div>
          </div>-->

         
 <div class="field-wrap">
           
 <label>
              Email Address<span class="req">*</span>
           
 </label>
          
  <input type="email"required autocomplete="off"/>
          </div>
          
         
 <div class="field-wrap">
            
<label>
              Set A Password<span class="req">*</span>
            </label>
          
  <input type="password"required autocomplete="off"/>
          
</div>

     <div class="field-wrap">
            
<label>
              Bank Account<span class="req">*</span>
            </label>
          
  <input type="account"required autocomplete="off"/>
          
</div>      
         
 <button type="submit" class="button button-block"/>Get Started</button>
          
          
</form>

       
 </div>
        
       
 <div id="login">   
         
 <h1>Welcome Back!</h1>
          
          
<form action="/" method="post">
          
          
  <div class="field-wrap">
           
 <label>
              
Email Address<span class="req">*</span>
           
 </label>
            
<input type="email"required autocomplete="off"/>
         
 </div>
          
         
 <div class="field-wrap">
          
  <label>
              Password<span class="req">*</span>
          
  </label>
            <input type="password"required autocomplete="off"/>
         
 </div>
          
          <p class="forgot"><a href="#">Forgot Password?</a></p>
          
        
  <button class="button button-block"/>Log In</button>
          
         
 </form>

       
 </div>
        
      
</div><!-- tab-content -->
      
</div>
 <!-- /form -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

   
 <script src="js/index.js"></script>


</body>
<?php
// function showRegistrationForm()
// {

//    print  "<form action='?act=register' method='post'>\n"
//          . "Email address: <label><input type='text' name='email' size='50'></label><br />\n"
//          . "Password: <label><input type='password' name='password' size='30'></label><br />\n"
//          . "Confirm your password: <label><input type='password' name='confirmPassword' size='30'></label><br />\n"
//          . "Debit Account Number: <label><input type='number' name='account' size='50'></label><br />\n"
//          . "<input type='submit' value='Register'>\n"
//          . "</form>\n";
//  }

 function processRegistration()
 {
     // check user input, to see if it's OK
     // in practice, it's better to do this in Javascript
     // but it's possible do perform this task on the
     // server side as well.
     $username = filter_input(INPUT_POST, "email");
     if(empty($username)) {
          die("Please enter your email address");
     }
     $password = filter_input(INPUT_POST, "password");
     if(empty($password)){
          die ("Please supply a password.");
     }
     $password_duplicate = filter_input(INPUT_POST, "confirmPassword");
     if(empty($password_duplicate)){
          die ("Please confirm your password.");
     }
     if($password != $password_duplicate) {
          die ("Passwords don't match.");
     }
     $account = filter_input(INPUT_POST, "account");
     if(empty($account)){
         die("Please enter your account number");
     }

    // connect with the database
	$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../Database/lecture07.mdb;Persist Security Info=False;";
	try {
		$conn = new COM('ADODB.Connection');
		$conn->ConnectionTimeout = 60;
		$conn->Open($connString);
	} catch (exception $e) {
		die( "Could not connect - $e");
	}
	// check that the email address (username) is not already in the database
	$sqlCommand = "SELECT * FROM customers WHERE email = '" . $username . "';";
	print $sqlCommand . "<p/>";
	$rs = $conn->Execute($sqlCommand);
	if(!$rs->EOF) {
	     $rs->Close();
	     die ("That email has already been taken.  Please use another.");
	}
	$rs->Close();
	//Yay!  We have good data.  Insert it into the database
	$date = date('d-m-Y H:i:s');
	$sqlCommand = "INSERT INTO customers (email, securityWord, account, dateJoined) VALUES ("
	               . "'$username','$password', '$account', #$date#);";

	print $sqlCommand;
    try {
        $conn->Execute($sqlCommand);
    }
    catch (exception $e) {
         die ("sql error:  $e");
    }
    $conn->Close();
    print "<p/> $username, You are now registered.  Thank you!<p/>
              <a href=login.php>Login</a> | <a href=index.php>Index</a>";

 }

 if (filter_has_var(INPUT_GET,"act"))
     processRegistration();
 else
     showRegistrationForm();
 ?>
</html>
