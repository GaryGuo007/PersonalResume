
<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />

<title>ECT 436</title>
</head>
<script type="text/javascript" async="async" defer="defer" data-cfasync="false" src="https://mylivechat.com/chatinline.aspx?hccid=98908127"></script>
<body>
<div class="container">
	<div class="head">
	<p><h1>ECT436 Social Marketing and Social Networking Applications</h1><h3>Winter 2017</h3></p>
	</div>

<div class="content">
		<div class="contact">
			<div class="photo"><img class="config1" src="headPortrait.jpg" alt="Xin Guo photo"/></div>
			<div class="devtxt1">
				<p><h2>Xin Guo</h2>
				Computer Science Graduate student<br />
			    Email: <a href="mailto:guoxin89749@gmail.com">guoxin89749@gmail.com</a><br />
				Website:<a href="https://www.linkedin.com/in/xin-guo-148aa292">https://www.linkedin.com/in/xin-guo-148aa292</a><br />
				</div>
		</div>
		<div class="row">
			<h3>Education</h3>
			Depaul University<br />
			<strong>Computer Science</strong> MS<br />
			Software and Systems Development<br />
			<br />
			Changchun Normal University (CNU), China<br />
			<strong>Cinema Production</strong> MS<br />
			 Radio and Television News Editing, Cinema Production<br />
		</div>

		<div class="row">
			<h3>Skill</h3>
			<strong>Language:</strong> J2EE, ASP.NET, PHP, PL / SQL, C<br />
			<strong>Web Design:</strong> HTML, CSS, Javascript<br />
			<strong>Software:</strong> 3DMAX, Audition, Premiere<br />
			<strong>Operation System:</strong> Windows, LINUX<br />
			<strong>Graphing Tool:</strong> PhotoShop<br />
		</div>
		
		<div class="row">
			<h3>Assignment Description</h3>
			<ul>
				<li><a href="../index.php">Assignment#1</a> Please create a simple HTML page that contains your personal information and links to your future assignments.</li>
				<li><a href="../assign2/index.php">Assignment#2</a> Develop a simple PHP Web site that allows a user to enter some information in a HTML form and responds to the user's input.</li>
				<li><a href="../assign3/index.php">Assignment#3</a> Develop a PHP page that uses at least two of the following control structures: if-else, switch, for loop, and while loop.</li>
				<li><a href="../deliverableA/index.php">Deliverable A</a> Design of the final project.</li>
				<li><a href="../assign4/index.php">Assignment#4</a> Develop PHP pages that take input from user and return records from database that match user input.</li>
				<li><a href="../deliverableB/index.php">Deliverable B</a> Final project Web site and documentation..</li>
			</ul>
		</div>
		<div class="footer">
			<p>This is an educational website.  Copyright 2017 All Rights reserved Xin Guo</p>
		</div>
	</div>

</div>
</body>
</html>