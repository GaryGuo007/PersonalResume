<!DOCTYPE html PUBLIC "-//w3c//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />

<title>ECT 436</title>
</head>
<body>
<div class="container">
	<div class="head">
	<p><h1>ECT436 Social Marketing and Social Networking Applications</h1><h3>Winter 2017</h3></p>
	</div>

	<div class="content"><a name="0"></a>
		<div class="sidebar">
			<ul>
			    <li><a href="http://ectweb.cs.depaul.edu/XGUO9/index.php">Home Page</a></li>
				<li><a href="#1">Website URL</a></li>
				<li><a href="#2">Value Proposition and Scopes</a></li>
				<li><a href="#3">Functional Requirements</a></li>
				<li><a href="#4">The Information Structure and Sitemap</a></li>
				<li><a href="#5">Activity Diagrams</a></li>
				<li><a href="#6">Interface requirement and wireframes</a></li>
				<li><a href="#7">Project Milestones</a></li>
			</ul>
		</div>
		<div class="proposal">
			<div>
			<h2>OnlineGambling - PHP Web Application Development Project Plan</h2>
			</div>
			<div class="point" name="1">
				<h2><a name="1">Website URL</a></h2>
				<p><a href="http://ectweb.cs.depaul.edu/XGUO9/assign4/index.php">http://ectweb.cs.depaul.edu/XGUO9/assign4/index.php</a></p>
			</div>
			<div class="point" >
				<h2><a name="2">Value Proposition and Scopes</a></h2>
				<p>This website provides a online gambling, Maybe you could be a millionaire suddenly.</p>
				<p>The main scopes are as following:
					<ol>
						<li>Secrecy:<br />
							<p>User just need provide their debit card number, they will get or lose money in a seconds through online money transmission.</p>
						</li>
						<li>Convenience:<br />
							<p>The website provides an interface for users to do online gambling any time they want. It's a light website, easy to login.</p>
						</li>
						<li>Easy:<br />
							<p>Just Big or small, two choices and six numbers, very easy to play.</p>
						</li>
					</ol>
				</p>
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>

			<div class="point" >
				<h2><a name="8">Competition</a></h2>
				<p><a href="https://www.casino.org/gambling/">1.https://www.casino.org/gambling/----Too many paragraphs.</p>
				<p><a href="https://www.onlinegambling.com/">2.https://www.onlinegambling.com/------Too expensive to play.</p>
				<p><a href="http://www.gambleonline.co/usa/">3.http://www.gambleonline.co/usa/------Too many play ways</p>
				
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>

			<div class="point" >
				<h2><a name="3">Functional Requirements</a></h2>
				<p>
					<ul>
						<li>Module 1 - Main Function<br />
							<p>Compare number to check the user is win or lose</p>
						</li>
						<li>Modules 2 - Login panel<br />
							<p>In order to provide more personalized schedule function, it is required to people to subject a registration to become a member who has authority to gambling.  When users enter their account, they are not only able to gmable but manage their personal account.</p>
						</li>
						<li>Module 3 - Registration panel<br />
							<p>With a registration feature, the system will receive the user subjected information and manage the membership so that the website system will judge if a new registration account has existed.</p>
						</li>
					</ul>
				</p>
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>
			<div class="point">
				<h2><a name="4">The Information Structure and Sitemap</a></h2>
				<table>
					<tr><td colspan="2" class="head">Business Requirements</td></tr>
					<tr><td colspan="2">Support membership management to give users individual services.</td></tr>
					<tr><td colspan="2">Facilitate user experience in the online gambling with usage history.</td></tr>
					<tr><td colspan="2" class="head">Technical Requirements</td></tr>
					<tr><td colspan="2" class="subhead">Pages</td></tr>
					<tr>
						<td width="20%">Home page</td>
						<td>Provide a greeting page with login panel for user to login and user instruction for new visitors to figure out the usage and register an account.</td>
					</tr>
					<tr>
						<td width="20%">Result page</td>
						<td>Provide a planning page for users to check win or lose.</td>
					</tr>
					<tr>
						<td width="20%">Login page</td>
						<td>User login</td>
					</tr>
					<tr>
						<td width="20%">Personal account page</td>
						<td>Check how much money they have, how much they win or lose.</td>
					</tr>
					<tr>
						<td width="20%">Registration page</td>
						<td>Provide a registration page for new visitors to be able to create new account with personal information submission.</td>
					</tr>
					<tr><td colspan="2" class="subhead">Database</td></tr>
					<tr>
						<td width="20%">Member database</td>
						<td>Build a database to store member information, email and bank account information for users can verify their personal profile and account.</td>
					</tr>
				</table>
				<h3>Sitemap</h3>
				<img src="sitemap.png" alt="sitemap"/>
				<h3>Database Entity Relationship Diagram</h3>
				<img src="database.png" alt="database"/>
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>
			<div class="point">
				<h2><a name="5">Activity Diagrams</a></h2>
				<img src="Activity_Diagram.png"  alt="Activity Diagram"/>
				<br />
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>
			<div class="point">
				<h2><a name="6">Interface requirement and wireframes</a></h2>
				<h3>Interface requirements </h3>
				<p>The application will perform under 1366x768 resolutions. JavaScript will be used for validation. A global CSS will be used for formatting.</p>
				<h3>Wireframe - website home page</h3>
				<img src="Homepage.png" alt="Homepage"/>
				<br />
				<img src="Registration.png" alt="module1"/>
				<br />
				<img src="Login.png" alt="module2"/>
				<br />
				<img src="Account.png" alt="module3"/>
				<br />
				<img src="Game.png" alt="module4"/>
				<br />
				<img src="Results.png" alt="module5"/>
				<p>The Main Content shows different contents depend on each page feature so it also provides different optional button(s) for navigation.  The dynamic content is based on each user's personal information displaying his or her owned travel schedule.  The layout plan is as following:</p>
				<table>
					<tr>
						<td class="field">Display Page</td>
						<td class="field">Main Content View</td>
					</tr>
					<tr>
						<td class="wcol1">Home Page</td>
						<td class="wcol2">Single view of the instruction illustration and description</td>
					</tr>
					<tr>
						<td class="wcol1">Result page</td>
						<td class="wcol2">List the result of gambling</td>
					</tr>
					<tr>
						<td class="wcol1">Profile page</td>
						<td class="wcol2">Detail view of information at a place</td>
					</tr>
					<tr>
						<td class="wcol1">Registration page</td>
						<td class="wcol2">Form view to enter and submit registration</td>
					</tr>
				</table>
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>
			<div class="point">
				<h2><a name="7">Project Milestones</a></h2>
				<table>
					<tr>
						<td class="field">Time Period</td>
						<td class="field">Milestone</td>
						<td class="field">Work Tasks</td>
						<td class="field">Technology and Information Source</td>
					</tr>
					<tr>
						<td class="mcol1">1/29/2017 - 2/4/2017</td>
						<td class="mcol2">Plan</td>
						<td class="mcol3">Scope Document<br />Structure Diagrams</td>
						<td class="mcol4">MS Word<br />UML in MS Visio</td>
					</tr>
					<tr>
						<td class="mcol1">2/5/2017 - 2/11/2017</td>
						<td class="mcol2">Design</td>
						<td class="mcol3">Pages Layout Design</td>
						<td class="mcol4">Photoshop and MS PowerPoint</td>
					</tr>
					<tr>
						<td class="mcol1">2/12/2017 - 2/18/2017</td>
						<td class="mcol2">Development</td>
						<td class="mcol3">Database Development<br />Home Page</td>
						<td class="mcol4">MS Access, XML online data sources[1]<br />CSS, XHTML</td>
					</tr>
					<tr>
						<td class="mcol1">2/19/2017 - 2/25/2017</td>
						<td class="mcol2">Development</td>
						<td class="mcol3">Review Page<br />Edit Page<br />Detail Page</td>
						<td class="mcol4">Database access in PHP<br />Create Schedule Class to show detail and execute the editing function</td>
					</tr>
					<tr>
						<td class="mcol1">2/26/2017 - 3/3/2017</td>
						<td class="mcol2">Development</td>
						<td class="mcol3">Frequent Spot Page<br />Registration Page</td>
						<td class="mcol4">Database access in PHP<br />JavaScript validation, session statement</td>
					</tr>
					<tr>
						<td class="mcol1">3/4/2017 - 3/10/2017</td>
						<td class="mcol2">Testing</td>
						<td class="mcol3">Test Scenarios<br />Test Recording Form<br />Test Running</td>
						<td class="mcol4">MS Word<br />Testing users</td>
					</tr>
					<tr>
						<td class="mcol1">3/11/2017 - 3/17/2017</td>
						<td class="mcol2">Implement</td>
						<td class="mcol3">Defect Resolution<br />Website Deployment</td>
						<td class="mcol4"></td>
					</tr>
				</table>
				<p>[1] Data Sources:
					<p>w3schools, http://www.w3schools.com/</p>
					<p>Entity Relationship Diagrams, https://erdplus.com</p>
				</p>
				<p><span class="back"><a href="#0">Go to top</a></p>
			</div>
			<div class="footer">
			<p>This is an educational website.  Copyright 2017 All Rights reserved Xin Guo and Wasan Tienchai</p>
		</div>
		</div>		
				
	</div>

</div>
</body>
</html>