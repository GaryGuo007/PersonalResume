<html>
<head>
	 <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
     <title>Beverages</title>
     <link rel="stylesheet" type="text/css" href="../../stylepage.css">
</head>
<body>
<h1>Beverages</h1>

<h4>Please click on the product to see more details:</h4>

<div>
<?php

$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../Database/Northwind.mdb;Persist Security Info=False;";
//creates the connection object and define the connection string

try {
	$conn = new COM('ADODB.Connection');
	$conn->ConnectionTimeout = 60;
	$conn->Open($connString);
} catch (exception $e) {
		die( "Could not connect - $e");
}
   print "<ul>";
$rs = $conn->Execute("SELECT ProductName, ProductID FROM Products WHERE CategoryID=1");
//opens a recordset from the connection object
    while (!$rs->EOF) {
    //keep looping until end of file
		$fv1=$rs->Fields("ProductID");
		$fv2=$rs->Fields("ProductName");
		print "<li><a href='moredetails.php?productid=$fv1'>";
		print "$fv2</a></li>";
		$rs->MoveNext();
	}
    $rs->Close();
    print "</ul>";
?>
</div>
</body>
</html>
