<html>
<head>
   <title>Beverage Details</title>
   <link rel="stylesheet" type="text/css" href="../../stylepage.css">
</head>
<body>
<?php
$productid=filter_input(INPUT_GET, "productid");


$conn = new COM("ADODB.Connection") or die("Cannot start ADO");
//$connString= "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=../../Database/Northwind.mdb";
$connString= "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=../Database/northwind.mdb";
//creates the connection object and define the connection string

$conn->Open($connString);

$selectCommand="SELECT ProductName, QuantityPerUnit, UnitPrice, UnitsInStock FROM Products WhERE ProductID=$productid;";

$rs = $conn->Execute($selectCommand);
//opens a recordset from the connection object
if (!$rs->EOF){
$ProductName=$rs->Fields("ProductName");
$QuantityPerUnit=$rs->Fields("QuantityPerUnit");
$UnitPrice=$rs->Fields("UnitPrice");
$UnitsInStock=$rs->Fields("UnitsInStock");
}

print "Product Name: $ProductName<br>";
print "Quantity Per Unit: $QuantityPerUnit<br>";
print "Unit Price: $UnitPrice<br>";
print "Units in Stock: $UnitsInStock<br>";
$rs->Close;

// arguments to setcookie:
//    1.  cookie name
//    2.  cookie value
//    3.  expiration (in seconds)
//    4.  top-level path where cookie is valid
//    5.  domain.  Cookies are value only for the host and domain
//             where they are created.  If null, server will fill in for you
//    6.  Security.  if == 1, cookie will only be transmitted via HTTPS
setcookie("productid", "$productid", time()+14400, "/", "", 0);

?>

</body>
</html>
